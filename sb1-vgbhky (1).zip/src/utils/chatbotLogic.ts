// This file is no longer needed for the simple chatbot version
// You can delete this file or leave it empty