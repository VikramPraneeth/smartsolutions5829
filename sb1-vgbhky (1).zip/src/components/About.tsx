import React from 'react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1471&q=80" alt="Team working" className="rounded-lg shadow-md" />
          </div>
          <div className="md:w-1/2 md:pl-12">
            <h2 className="text-3xl font-bold mb-4">About Smart Solutions</h2>
            <p className="text-gray-600 mb-4">
              At Smart Solutions, we're passionate about leveraging cutting-edge AI technologies to solve complex business challenges. Our team of experts combines deep technical knowledge with creative thinking to deliver innovative solutions that drive growth and efficiency.
            </p>
            <p className="text-gray-600">
              With years of experience in AI, design, and marketing, we're committed to helping businesses of all sizes harness the power of technology to achieve their goals and stay ahead in today's competitive landscape.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;